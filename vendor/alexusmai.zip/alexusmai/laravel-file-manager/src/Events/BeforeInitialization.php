<?php

namespace Alexusmai\LaravelFileManager\Events;

class BeforeInitialization
{
    /**
     * BeforeInitialization constructor.
     */
    public function __construct()
    {

    }
}
