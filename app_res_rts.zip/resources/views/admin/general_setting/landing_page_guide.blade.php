<div class="modal fade" id="landing_page_guide" tabindex="-1" role="dialog" aria-labelledby="landing_page_guideLabel"
    aria-hidden="true">
    <div class="modal-dialog modal-xl" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="landing_page_guideLabel">Guide for setting Landing Page</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="container-fluid p-1">
                    <img src="{{ asset('public/frontend/images/dummy-landing-page.jpg') }}" alt="Dummy Landing Image"
                        class="w-100">
                </div>
            </div>
        </div>
    </div>
</div>
