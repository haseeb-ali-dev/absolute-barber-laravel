<div class="pr-2">
    <img src="{{ asset('public/frontend/images/schedule.png') }}" alt="Calendar">
</div>
