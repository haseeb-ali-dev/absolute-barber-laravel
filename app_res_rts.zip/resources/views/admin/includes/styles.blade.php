<link rel="stylesheet" href="{{ asset('public/backend/vendor/fontawesome-free/css/all.min.css') }}">
<link rel="stylesheet" href="{{ asset('public/backend/css/sb-admin-2.min.css') }}">
<link rel="stylesheet" href="{{ asset('public/backend/vendor/datatables/dataTables.bootstrap4.min.css') }}">
<link rel="stylesheet" href="{{ asset('public/backend/css/toastr.min.css') }}">
<link rel="stylesheet" href="{{ asset('public/backend/css/jquery-ui.css') }}">
<link rel="stylesheet" href="{{ asset('public/backend/css/jquery.timepicker.css') }}">
<link rel="stylesheet" href="{{ asset('public/backend/css/summernote-bs4.min.css') }}">
<link rel="stylesheet" href="{{ asset('public/backend/css/spacing.css') }}">
<link rel="stylesheet" href="{{ asset('public/backend/css/style.css') }}">
<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
<link rel="stylesheet" href="{{ asset('public/backend/css/rte_theme_default.css') }}">
