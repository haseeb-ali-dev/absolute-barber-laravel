<script src="{{ asset('public/backend/vendor/jquery/jquery.min.js') }}"></script>
<script src="{{ asset('public/backend/vendor/bootstrap/js/bootstrap.bundle.min.js') }}"></script>
<script src="{{ asset('public/backend/vendor/jquery-easing/jquery.easing.min.js') }}"></script>
<script src="{{ asset('public/backend/vendor/datatables/jquery.dataTables.min.js') }}"></script>
<script src="{{ asset('public/backend/vendor/datatables/dataTables.bootstrap4.min.js') }}"></script>
<script src="{{ asset('public/backend/js/demo/datatables-demo.js') }}"></script>
<script src="{{ asset('public/backend/js/toastr.min.js') }}"></script>
<script src="{{ asset('public/backend/js/jscolor.js') }}"></script>
<script src="{{ asset('public/backend/js/jquery.timepicker.js') }}"></script>
<script src="{{ asset('public/backend/js/jquery-ui.js') }}"></script>
<script src="{{ asset('public/backend/js/summernote-bs4.min.js') }}"></script>
<script src="{{ asset('public/backend/js/rte.js') }}"></script>
<script src="{{ asset('public/backend/js/all_plugins.js') }}"></script>

